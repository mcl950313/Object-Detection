#!/usr/bin/env bash
set -euo pipefail
TASK_SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
if ! command -v python3 >/dev/null 2>&1; then
  echo "未找到 Python 3。请安装 Python 3.10 或更新版本后重试。" >&2
  exit 1
fi
if ! python3 -c 'import sys; raise SystemExit(sys.version_info < (3, 10))'; then
  echo "需要 Python 3.10 或更新版本。" >&2
  exit 1
fi
# Deliberately preserve the caller's current working directory.
exec python3 -u "$TASK_SCRIPT_DIR/down_SimNICT_chest.py" "$@"

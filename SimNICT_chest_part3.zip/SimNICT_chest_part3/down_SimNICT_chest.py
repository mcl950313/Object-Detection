#!/usr/bin/env python3
"""Download one complete, fixed shard of the 5,512 public SimNICT chest volumes.

Python 3.10+, standard library only. The three shards together cover all public
chest reference CT files exactly once. Default output is under the caller's
current working directory, independent of the location of this script.

No payload is downloaded on import, --check, --dry-run or --probe.  Re-run after
Ctrl+C/network failure to verify completed files and resume .part files.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import email.utils
import errno
import fcntl
import gzip
import hashlib
import http.client
import json
import math
import os
from pathlib import Path
import re
import shutil
import socket
import ssl
import struct
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass

PART_NUMBER = 3
DATA_SUBDIR = f'SimNICT_chest_part{PART_NUMBER}_data'
VERSION = 'full-chest-three-parts-v1'
MANIFEST_NAME = 'down_SimNICT_chest_manifest.csv'
MANIFEST_SHA256 = 'a6b1c4d046532dff426bad528febd54dd66441e86e2a5af996185fa86cc918c5'
MIRRORS_NAME = 'down_SimNICT_chest_mirrors.json'
MIRRORS_SHA256 = '5ce6f018e7cda528bc715a34f41841514735781910d5c5fdc59be1bf95f81ffe'
DIAGNOSTIC_BYTES = 64 * 1024
EXPECTED_COUNT = 1837
EXPECTED_BYTES = 189616032253
ALLOWED_IDS = frozenset({
    'simnict-covid-19-ny-sbu', 'simnict-ct-images-in-covid-19',
    'simnict-lndb', 'simnict-luna', 'simnict-mela', 'simnict-stoic',
})
SOURCE_LICENSE_LABELS = {
    'simnict-covid-19-ny-sbu': 'CC BY 4.0',
    'simnict-ct-images-in-covid-19': 'CC BY 4.0',
    'simnict-lndb': 'CC BY-NC-ND 4.0',
    'simnict-luna': 'CC BY 4.0',
    'simnict-mela': 'CC BY 4.0',
    'simnict-stoic': 'CC BY-NC 4.0',
}
BLOCK = 1024 * 1024
USER_AGENT = 'SimNICT-chest-full-shard/1.0 (Python urllib; sequential; resumable)'


class DownloadError(Exception):
    pass


class IntegrityError(DownloadError):
    pass


class NetworkError(DownloadError):
    """A failed transfer that remains safe to resume."""

    def __init__(self, message, transferred_bytes=0):
        super().__init__(message)
        self.transferred_bytes = transferred_bytes


@dataclass(frozen=True)
class Entry:
    identifier: str
    source_dataset: str
    filename: str
    size_bytes: int
    md5: str
    sha1: str
    rank: int
    url: str

    def path(self, root: Path) -> Path:
        return root / self.identifier / self.filename


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def human_size(n: int) -> str:
    return f'{n / 1e9:,.2f} GB ({n / 2**30:,.2f} GiB)'


def format_rate(bytes_per_second: float) -> str:
    for scale, unit in ((1e9, 'GB/s'), (1e6, 'MB/s'), (1e3, 'KB/s')):
        if bytes_per_second >= scale:
            return f'{bytes_per_second / scale:,.2f} {unit}'
    return f'{max(0.0, bytes_per_second):,.0f} B/s'


def format_eta(seconds: float | None) -> str:
    if seconds is None or not math.isfinite(seconds):
        return '--'
    seconds = max(0, math.ceil(seconds))
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f'{hours:02d}:{minutes:02d}:{seconds:02d}' if hours else f'{minutes:02d}:{seconds:02d}'


class TransferProgress:
    """Refresh independently of blocking network reads; resume bytes are not speed."""

    def __init__(self, total, offset=0, *, stream=None, interval=1.0, log_interval=10.0, clock=None, source=''):
        self.total, self.offset, self.received = total, offset, 0
        self.stream = sys.stdout if stream is None else stream
        self.interval, self.log_interval = interval, log_interval
        self.clock = time.monotonic if clock is None else clock
        self.started = self.clock()
        self.samples = collections.deque([(self.started, 0)])
        self.phase = f'正在连接服务器 {source}'.strip()
        self.lock, self.stop_event = threading.Lock(), threading.Event()
        self.thread = None
        self.terminal = bool(getattr(self.stream, 'isatty', lambda: False)())

    def begin(self, offset):
        with self.lock:
            self.offset = offset
            self.started = self.clock()
            self.samples = collections.deque([(self.started, self.received)])
            self.phase = '下载中'

    def advance(self, size):
        with self.lock:
            self.received += size

    def frame(self, now=None):
        now = self.clock() if now is None else now
        with self.lock:
            self.samples.append((now, self.received))
            while len(self.samples) > 2 and self.samples[1][0] <= now - 5:
                self.samples.popleft()
            earlier_time, earlier_bytes = self.samples[0]
            rate = (self.received - earlier_bytes) / max(now - earlier_time, 0.001)
            average = self.received / max(now - self.started, 0.001)
            current = self.offset + self.received
            remaining = max(0, self.total - current)
            eta = 0 if not remaining else remaining / rate if rate > 0 else None
            phase = self.phase
        return (f'{phase} {current / max(self.total, 1):6.1%} | '
                f'{current / 1e6:,.1f}/{self.total / 1e6:,.1f} MB | '
                f'速度 {format_rate(rate)} | 平均 {format_rate(average)} | 本文件剩余 {format_eta(eta)}')

    def render(self, final=False):
        line = '    ' + self.frame()
        if self.terminal:
            self.stream.write('\r\x1b[2K' + line + ('\n' if final else ''))
        else:
            self.stream.write(line + '\n')
        self.stream.flush()

    def refresh(self):
        delay = self.interval if self.terminal else self.log_interval
        while not self.stop_event.wait(delay):
            self.render()

    def __enter__(self):
        self.render()
        self.thread = threading.Thread(target=self.refresh, name='SimNICT-download-progress', daemon=True)
        self.thread.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.stop_event.set()
        if self.thread is not None:
            self.thread.join()
        with self.lock:
            self.phase = '传输中断' if exc_type else '接收完成，正在校验'
        self.render(final=True)


def load_manifest(path: Path) -> list[Entry]:
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != MANIFEST_SHA256:
        raise IntegrityError('Manifest SHA-256 differs from the pinned download plan. Restore the supplied manifest; do not use an edited plan.')
    rows = list(csv.DictReader(raw.decode('utf-8-sig').splitlines()))
    result = []
    for row in rows:
        identifier, name = row['identifier'], row['filename']
        if identifier not in ALLOWED_IDS or not re.fullmatch(r'[A-Za-z0-9_-]+\.nii\.gz', name):
            raise IntegrityError(f'Unsafe or out-of-scope manifest entry: {identifier}/{name}')
        size, rank = int(row['size_bytes']), int(row['download_order'])
        md5, sha1 = row['reported_md5'].lower(), row['reported_sha1'].lower()
        if size <= 0 or not re.fullmatch('[0-9a-f]{32}', md5) or not re.fullmatch('[0-9a-f]{40}', sha1):
            raise IntegrityError(f'Invalid size/checksum: {identifier}/{name}')
        url = f'https://archive.org/download/{identifier}/{urllib.parse.quote(name)}'
        if row['source_file_url'] != url:
            raise IntegrityError(f'Unexpected download URL: {identifier}/{name}')
        if row.get('region', 'chest') != 'chest':
            raise IntegrityError('The plan contains a non-chest entry.')
        result.append(Entry(identifier, row['source_dataset'], name, size, md5, sha1, rank, url))
    if len(result) != EXPECTED_COUNT or sum(x.size_bytes for x in result) != EXPECTED_BYTES:
        raise IntegrityError('Manifest count or total size differs from this pinned chest shard.')
    if len({(x.identifier, x.filename) for x in result}) != len(result):
        raise IntegrityError('The manifest repeats an output path.')
    if {x.rank for x in result} != set(range(1, EXPECTED_COUNT + 1)):
        raise IntegrityError(f'Manifest download order must contain exactly 1..{EXPECTED_COUNT}.')
    return sorted(result, key=lambda x: x.rank)


def valid_mirror_base(url: str, identifier: str) -> bool:
    try:
        parsed = urllib.parse.urlsplit(url)
        return (allowed_url(url) and not parsed.query and not parsed.fragment
                and bool(re.fullmatch(r'(?:/\d+/items/' + re.escape(identifier)
                                         + r'/|/download/' + re.escape(identifier) + r'/)', parsed.path)))
    except (ValueError, TypeError):
        return False


def load_mirrors(path: Path) -> dict[str, list[str]]:
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != MIRRORS_SHA256:
        raise IntegrityError('Official server list SHA-256 differs from the supplied pinned plan. Restore the supplied JSON file.')
    data = json.loads(raw)
    if data.get('schema_version') != 1 or set(data.get('sources', {})) != ALLOWED_IDS:
        raise IntegrityError('Official server list has an unexpected schema/source set.')
    result = {}
    for identifier, source in data['sources'].items():
        urls = source.get('urls', [])
        if not isinstance(urls, list) or not 1 <= len(urls) <= 3:
            raise IntegrityError(f'Expected 1..3 official routes for {identifier}.')
        if any(not isinstance(url, str) or not valid_mirror_base(url, identifier) for url in urls):
            raise IntegrityError(f'Invalid official server URL for {identifier}.')
        if len(set(urls)) != len(urls):
            raise IntegrityError(f'Duplicate official server route for {identifier}.')
        direct = [url for url in urls if urllib.parse.urlsplit(url).hostname != 'archive.org']
        canonical = f'https://archive.org/download/{identifier}/'
        result[identifier] = direct + ([canonical] if canonical not in direct else [])
        if len(result[identifier]) > 3:
            raise IntegrityError('Too many official routes; diagnostics are limited to 18 probes.')
    return result


class MirrorRouter:
    def __init__(self, sources):
        self.sources = sources
        self.preferred = {}

    def candidates(self, entry):
        bases = list(self.sources[entry.identifier])
        preferred = self.preferred.get(entry.identifier)
        if preferred in bases:
            bases.remove(preferred)
            bases.insert(0, preferred)
        return [(base, base + urllib.parse.quote(entry.filename, safe='')) for base in bases]

    def success(self, entry, base):
        self.preferred[entry.identifier] = base

    def apply_diagnostic_report(self, path):
        """Use local probe results only to order already-pinned official routes."""
        size = checked_file_size(path)
        if size is None:
            return
        if size > 512 * 1024:
            print('已有诊断报告过大，忽略其线路排序。', flush=True)
            return
        try:
            report = json.loads(path.read_text(encoding='utf-8'))
            if report.get('schema_version') != 1:
                return
            best = {}
            for record in report.get('routes', []):
                identifier = record.get('identifier')
                base = record.get('url', '').rsplit('/', 1)[0] + '/'
                if base not in self.sources.get(identifier, []):
                    continue
                observed, speed = record.get('bytes_read', 0), float(record.get('bytes_per_second', 0))
                latency = record.get('first_byte_seconds')
                if (not isinstance(observed, int) or observed <= 0 or not math.isfinite(speed) or speed <= 0
                        or not isinstance(latency, (int, float)) or not math.isfinite(latency) or latency < 0):
                    continue
                score = (speed, -latency)
                if identifier not in best or score > best[identifier][0]:
                    best[identifier] = (score, base)
            for identifier, (_, base) in best.items():
                self.preferred[identifier] = base
            if best:
                print(f'使用已有网络诊断为 {len(best)} 个来源选择收到数据且测试较快的官方线路；小样本速度仅供排序。', flush=True)
        except (ValueError, TypeError, AttributeError):
            print('已有诊断报告格式不完整，忽略其线路排序。', flush=True)


def error_classification(exc: BaseException) -> str:
    """Stable diagnostics without echoing proxy URLs, credentials or cookies."""
    reason = getattr(exc, 'reason', exc)
    if isinstance(reason, (ssl.SSLCertVerificationError, ssl.CertificateError)):
        return 'certificate_verification_failed'
    if isinstance(reason, ssl.SSLError):
        return 'tls_error'
    if isinstance(reason, socket.gaierror):
        return 'dns_error'
    if isinstance(reason, (TimeoutError, socket.timeout)):
        return 'timeout'
    if isinstance(exc, urllib.error.HTTPError):
        return f'http_{exc.code}'
    if isinstance(reason, ConnectionRefusedError):
        return 'connection_refused'
    if isinstance(reason, ConnectionResetError):
        return 'connection_reset'
    if isinstance(exc, IntegrityError):
        return 'invalid_response'
    if isinstance(reason, OSError):
        return f'network_os_error_{reason.errno}'
    return 'connection_or_proxy_error'


def assert_no_symlink(path: Path) -> None:
    """Reject symlink components even when the final leaf does not yet exist."""
    path = Path(os.path.abspath(path))
    for component in reversed((path, *path.parents)):
        if component.is_symlink():
            raise DownloadError(f'Refusing a symlink in the download path: {component}')
        if component.exists() and component != path and not component.is_dir():
            raise DownloadError(f'Parent path is not a directory: {component}')


def make_directory(path: Path) -> None:
    assert_no_symlink(path)
    path.mkdir(parents=True, exist_ok=True)
    assert_no_symlink(path)
    if not path.is_dir():
        raise DownloadError(f'Not a directory: {path}')


def checked_file_size(path: Path) -> int | None:
    assert_no_symlink(path)
    if path.exists():
        if not path.is_file():
            raise DownloadError(f'Expected a regular file: {path}')
        return path.stat().st_size
    return None


def hash_file(path: Path) -> dict[str, str]:
    assert_no_symlink(path)
    hashes = {key: hashlib.new(key) for key in ('md5', 'sha1', 'sha256')}
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0)
    with os.fdopen(os.open(path, flags), 'rb') as stream:
        while chunk := stream.read(BLOCK):
            for value in hashes.values():
                value.update(chunk)
    return {key: value.hexdigest() for key, value in hashes.items()}


def verify_file(entry: Entry, path: Path) -> dict[str, str]:
    size = checked_file_size(path)
    if size != entry.size_bytes:
        raise IntegrityError(f'Wrong size for {path}: {size}; expected {entry.size_bytes}. File preserved.')
    hashes = hash_file(path)
    if hashes['md5'] != entry.md5 or hashes['sha1'] != entry.sha1:
        raise IntegrityError(f'MD5/SHA-1 mismatch for {path}. File preserved: rename or inspect it before retrying.')
    return hashes


def inspect_nifti_header(path: Path) -> dict:
    """Read only the NIfTI header, without loading a complete volume into RAM."""
    def finite(value: float):
        # NIfTI permits NaN scaling values for unspecified scaling. JSON has no
        # representation for NaN/Inf; null preserves that meaning without errors.
        return value if math.isfinite(value) else None

    try:
        with gzip.open(path, 'rb') as stream:
            header = stream.read(540)
        if len(header) < 348:
            return {'nifti_header_error': 'short header'}
        order = '<' if struct.unpack('<i', header[:4])[0] in (348, 540) else '>'
        version = struct.unpack(order + 'i', header[:4])[0]
        if version == 348:
            dims = struct.unpack_from(order + '8h', header, 40)
            pixdim = struct.unpack_from(order + '8f', header, 76)
            return {'nifti_version': 1, 'shape': list(dims[1:1 + min(max(dims[0], 0), 7)]),
                    'voxel_spacing': [finite(v) for v in pixdim[1:4]], 'datatype': struct.unpack_from(order + 'h', header, 70)[0],
                    'scl_slope': finite(struct.unpack_from(order + 'f', header, 112)[0]),
                    'scl_inter': finite(struct.unpack_from(order + 'f', header, 116)[0])}
        if version == 540 and len(header) >= 540:
            dims = struct.unpack_from(order + '8q', header, 16)
            pixdim = struct.unpack_from(order + '8d', header, 104)
            return {'nifti_version': 2, 'shape': list(dims[1:1 + min(max(dims[0], 0), 7)]),
                    'voxel_spacing': [finite(v) for v in pixdim[1:4]], 'datatype': struct.unpack_from(order + 'h', header, 12)[0]}
        return {'nifti_header_error': 'unrecognized NIfTI header'}
    except (OSError, EOFError, struct.error) as exc:
        return {'nifti_header_error': str(exc)}


def allowed_url(url: str) -> bool:
    parsed = urllib.parse.urlsplit(url)
    host = (parsed.hostname or '').lower()
    return (parsed.scheme == 'https' and parsed.port in (None, 443)
            and not parsed.username and not parsed.password
            and (host == 'archive.org' or host.endswith('.archive.org')))


class ArchiveRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not allowed_url(newurl):
            raise DownloadError('Refusing a redirect outside HTTPS archive.org servers.')
        redirected = super().redirect_request(req, fp, code, msg, headers, newurl)
        # urllib's default changes redirected HEAD to GET: preserve the method.
        if redirected is not None:
            redirected.method = req.get_method()
        return redirected


def make_opener(direct=False):
    # No credentials or browser cookies are needed for these public IA files.
    handlers = [ArchiveRedirect(), urllib.request.HTTPSHandler(context=ssl.create_default_context())]
    if direct:
        handlers.insert(0, urllib.request.ProxyHandler({}))
    else:
        proxies = urllib.request.getproxies()
        if any(urllib.parse.urlsplit(proxies.get(key, '')).scheme.lower().startswith('socks') for key in ('http', 'https')):
            raise DownloadError('当前 HTTP_PROXY/HTTPS_PROXY 使用 SOCKS 协议；Python 标准库不支持。请使用已有获授权代理的 HTTP 端口配置 HTTPS_PROXY（不要把代理密码贴到日志），或有意直连时使用 --direct。')
        if proxies.get('all') and not proxies.get('https'):
            print('提示：标准库不会使用 ALL_PROXY 作为 HTTPS 代理；若需要已有获授权代理，请配置 HTTPS_PROXY 的 HTTP 端口。', flush=True)
    return urllib.request.build_opener(*handlers)


def request(opener, url: str, *, method='GET', offset=0, timeout=15, range_end=None):
    if not allowed_url(url):
        raise DownloadError('Refusing an unapproved source URL.')
    headers = {'User-Agent': USER_AGENT, 'Accept-Encoding': 'identity'}
    if offset or range_end is not None:
        headers['Range'] = f'bytes={offset}-' + (str(range_end) if range_end is not None else '')
    return opener.open(urllib.request.Request(url, headers=headers, method=method), timeout=timeout)


def probe_route(opener, entry, url, timeout=8.0):
    """Bound the caller's wait and never retain more than 64 KiB per route.

    DNS lookups cannot always be interrupted by urllib's socket timeout. A
    daemon worker therefore lets the report proceed after the wall deadline;
    cancellation prevents a late DNS completion from starting a payload read.
    """
    started = time.monotonic()
    cancelled = threading.Event()
    result = {'host': urllib.parse.urlsplit(url).hostname, 'effective_host': None, 'url': url,
              'status': None, 'bytes_read': 0, 'first_byte_seconds': None,
              'elapsed_seconds': None, 'bytes_per_second': 0.0,
              'classification': 'deadline_exceeded'}
    completed = {}
    live = dict(result)
    progress_lock = threading.Lock()

    def publish_progress(record):
        with progress_lock:
            live.update(record)

    def worker():
        record = dict(result)
        try:
            with request(opener, url, range_end=DIAGNOSTIC_BYTES - 1, timeout=timeout) as response:
                if cancelled.is_set():
                    return
                record['status'] = response.status
                effective_url = response.geturl() if callable(getattr(response, 'geturl', None)) else url
                if not isinstance(effective_url, str) or not allowed_url(effective_url):
                    raise IntegrityError('Probe returned an unapproved effective URL')
                record['effective_host'] = urllib.parse.urlsplit(effective_url).hostname
                publish_progress(record)
                if response.status not in (200, 206):
                    raise NetworkError('Unexpected HTTP status')
                if response.headers.get('Content-Encoding', 'identity').lower() not in ('identity', ''):
                    raise IntegrityError('Modified response encoding')
                if response.status == 206:
                    content_range = response.headers.get('Content-Range', '')
                    match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', content_range)
                    if (not match or int(match[1]) != 0 or int(match[3]) != entry.size_bytes
                            or not 0 <= int(match[2]) < min(DIAGNOSTIC_BYTES, entry.size_bytes)):
                        raise IntegrityError('Invalid probe range')
                expected = min(DIAGNOSTIC_BYTES, entry.size_bytes)
                while record['bytes_read'] < expected and not cancelled.is_set():
                    if time.monotonic() - started >= timeout:
                        raise TimeoutError('Probe deadline')
                    size = expected - record['bytes_read']
                    reader = getattr(response, 'read1', None)
                    chunk = reader(size) if callable(reader) else response.read(size)
                    if not chunk:
                        break
                    if record['first_byte_seconds'] is None:
                        record['first_byte_seconds'] = round(time.monotonic() - started, 3)
                    record['bytes_read'] += len(chunk)
                    publish_progress(record)
                record['classification'] = 'reachable' if record['bytes_read'] else 'empty_response'
        except Exception as exc:
            record['classification'] = error_classification(exc)
        elapsed = time.monotonic() - started
        record['elapsed_seconds'] = round(elapsed, 3)
        record['bytes_per_second'] = round(record['bytes_read'] / max(elapsed, 0.001), 1)
        with progress_lock:
            if not cancelled.is_set():
                completed.update(record)

    thread = threading.Thread(target=worker, name='SimNICT-network-probe', daemon=True)
    thread.start()
    thread.join(timeout)
    if thread.is_alive():
        cancelled.set()
        with progress_lock:
            result.update(live)
        result['elapsed_seconds'] = round(time.monotonic() - started, 3)
        result['bytes_per_second'] = round(result['bytes_read'] / max(result['elapsed_seconds'], 0.001), 1)
        result['classification'] = 'slow_response_deadline' if result['bytes_read'] else 'deadline_exceeded'
        result['note'] = 'Caller deadline reached. An OS DNS/proxy operation may still finish in the background; no volume is saved.'
        return result
    return completed or result


def network_help() -> str:
    return ('官方线路没有收到数据时，换域名或重试不保证能解决网络不可达。请把 network_diagnostic.txt '
            '交给朋友或网络管理员，检查 DNS、出口连接及已有代理设置；若已有获授权的 HTTPS 代理，'
            '可通过 HTTPS_PROXY 环境变量使用。只有怀疑系统代理配置错误时才另试 --direct。'
            '脚本不会关闭证书验证，也不包含第三方镜像。')


def run_diagnosis(entries, router, opener, data_dir, *, direct=False, timeout=8):
    first = {}
    for entry in entries:
        first.setdefault(entry.identifier, entry)
    proxy_names = sorted(key for key in os.environ
                         if key.lower() in ('http_proxy', 'https_proxy', 'all_proxy', 'no_proxy'))
    report = {'schema_version': 1, 'version': VERSION, 'time_utc': utc_now(),
              'proxy_mode': 'direct' if direct else 'system_environment',
              'proxy_variable_names_present': proxy_names, 'probe_limit_bytes_per_route': DIAGNOSTIC_BYTES,
              'probe_timeout_seconds': timeout, 'routes': []}
    print('网络诊断：每条官方线路最多读取 64 KiB，不保存 CT，不要求整份数据的存储空间。', flush=True)
    print(f'代理模式: {report["proxy_mode"]}; 仅记录变量名称，不记录代理值/密码。', flush=True)
    for group_index, (identifier, entry) in enumerate(first.items(), 1):
        routes = router.candidates(entry)
        print(f'[{group_index}/{len(first)}] {identifier}: {len(routes)} 条官方线路', flush=True)
        for _, url in routes:
            host = urllib.parse.urlsplit(url).hostname
            print(f'  检查 {host}（最多等待 {timeout} 秒）...', flush=True)
            record = probe_route(opener, entry, url, timeout=timeout)
            record['identifier'] = identifier
            report['routes'].append(record)
            print(f'    {record["classification"]} | HTTP {record["status"] or "--"} | '
                  f'{record["bytes_read"]} B | {format_rate(record["bytes_per_second"])}', flush=True)
    report['reachable_routes'] = sum(r['bytes_read'] > 0 for r in report['routes'])
    report['all_sources_reachable'] = all(any(r['identifier'] == identifier and r['bytes_read'] > 0
                                             for r in report['routes']) for identifier in first)
    make_directory(data_dir)
    path = data_dir / 'network_diagnostic.json'
    atomic_json(path, report)
    lines = [f'SimNICT {VERSION} network diagnosis | {report["time_utc"]}',
             f'Proxy mode: {report["proxy_mode"]}; variable names present: {", ".join(proxy_names) or "none"}',
             'Proxy values, credentials and cookies are not recorded.',
             f'Each route reads at most {DIAGNOSTIC_BYTES} bytes; these tiny probes do not predict sustained download speed.']
    lines.extend(f'{r["identifier"]} | {r["host"]} -> {r["effective_host"] or "not_connected"} | {r["classification"]} | HTTP {r["status"]} | '
                 f'{r["bytes_read"]} bytes | first byte {r["first_byte_seconds"]} s | '
                 f'{format_rate(r["bytes_per_second"])}' for r in report['routes'])
    lines.extend(['', network_help(),
                  'An OS DNS/proxy call may outlive its caller deadline in a daemon worker; no volume is saved.'])
    text_path = data_dir / 'network_diagnostic.txt'
    assert_no_symlink(text_path)
    descriptor = os.open(text_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
        stream.write('\n'.join(lines) + '\n')
    print(f'诊断完成：{report["reachable_routes"]}/{len(report["routes"])} 条线路收到数据。\n报告: {text_path}', flush=True)
    if not report['all_sources_reachable']:
        print(network_help(), flush=True)
    return 0 if report['all_sources_reachable'] else 2


def retry_delay(exc: BaseException, attempt: int) -> float:
    delay = min(30.0, 2.0 ** attempt)
    if isinstance(exc, urllib.error.HTTPError):
        value = exc.headers.get('Retry-After', '')
        try:
            delay = float(value)
        except ValueError:
            try:
                when = email.utils.parsedate_to_datetime(value)
                delay = (when - dt.datetime.now(dt.timezone.utc)).total_seconds()
            except (ValueError, TypeError, OverflowError):
                pass
    return max(1.0, min(60.0, delay))


def check_capacity(path: Path, bytes_needed: int, reserve_bytes: int) -> int:
    ancestor = path
    while not ancestor.exists():
        ancestor = ancestor.parent
    free = shutil.disk_usage(ancestor).free
    if free < bytes_needed + reserve_bytes:
        raise DownloadError(f'Insufficient free space: {human_size(free)} available; {human_size(bytes_needed + reserve_bytes)} needed including reserve.')
    return free


def open_partial(path: Path, append: bool):
    assert_no_symlink(path)
    flags = os.O_WRONLY | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0)
    flags |= os.O_APPEND if append else os.O_TRUNC
    return os.fdopen(os.open(path, flags, 0o600), 'ab' if append else 'wb')


def publish_no_overwrite(part: Path, final: Path) -> None:
    """Prefer atomic hard-link publish, with exclusive-copy fallback for disks without links."""
    assert_no_symlink(part)
    assert_no_symlink(final)
    try:
        os.link(part, final, follow_symlinks=False)
    except OSError as exc:
        if exc.errno not in (errno.EPERM, errno.EOPNOTSUPP, errno.EXDEV, errno.ENOSYS, errno.EINVAL):
            raise
        descriptor = os.open(final, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        created_inode = os.fstat(descriptor).st_ino
        try:
            with os.fdopen(descriptor, 'wb') as destination, part.open('rb') as source:
                shutil.copyfileobj(source, destination, BLOCK)
                destination.flush()
                os.fsync(destination.fileno())
        except BaseException:
            if final.exists() and final.stat().st_ino == created_inode:
                final.unlink()
            raise
    part.unlink()


def download_one(entry: Entry, final: Path, opener, *, retries=2, timeout=15, reserve_bytes=0, router=None) -> dict:
    make_directory(final.parent)
    if checked_file_size(final) is not None:
        return verify_file(entry, final)
    part = final.with_name(final.name + '.part')
    candidates = router.candidates(entry) if router is not None else [(None, entry.url)]
    attempts = max(len(candidates), retries + 1)
    transferred = 0
    for attempt in range(attempts):
        base, url = candidates[attempt % len(candidates)]
        source_host = urllib.parse.urlsplit(url).hostname
        offset = checked_file_size(part) or 0
        if offset:
            print(f'    Resuming from {offset / 1e6:,.2f} MB ({offset / entry.size_bytes:.1%}); partial file retained.', flush=True)
        if offset > entry.size_bytes:
            raise IntegrityError(f'Oversized partial file preserved: {part}. Rename or inspect it before retrying.')
        if offset == entry.size_bytes:
            hashes = verify_file(entry, part)
            publish_no_overwrite(part, final)
            return hashes
        check_capacity(final.parent, entry.size_bytes - offset, reserve_bytes)
        try:
            print(f'    官方线路 {attempt + 1}/{attempts}: {source_host} | 单次网络等待超时 {timeout}s', flush=True)
            with TransferProgress(entry.size_bytes, offset, source=source_host) as progress, request(opener, url, offset=offset, timeout=timeout) as response:
                status = response.status
                if response.headers.get('Content-Encoding', 'identity').lower() not in ('identity', ''):
                    raise IntegrityError('Unexpected HTTP content encoding; refusing modified bytes.')
                if status == 206:
                    match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range', ''))
                    if not match:
                        raise IntegrityError('Missing/invalid Content-Range; partial file preserved.')
                    start, end, total = map(int, match.groups())
                    if start != offset or total != entry.size_bytes or not start <= end < total:
                        raise IntegrityError('Content-Range differs from requested offset/manifest; partial file preserved.')
                    expected_body = end - start + 1
                elif status == 200:
                    # A server may ignore Range; restart from zero, never append a full file.
                    offset = 0
                    expected_body = entry.size_bytes
                    check_capacity(final.parent, entry.size_bytes, reserve_bytes)
                else:
                    raise DownloadError(f'Unexpected HTTP status {status}')
                length = response.headers.get('Content-Length')
                if length and int(length) != expected_body:
                    raise IntegrityError('Content-Length differs from the pinned manifest/range.')
                received = 0
                progress.begin(offset)
                with open_partial(part, append=bool(offset)) as destination:
                    while True:
                        # read1 returns available bytes instead of waiting to fill
                        # a 1 MiB buffer on a slow connection.
                        reader = getattr(response, 'read1', None)
                        chunk = reader(BLOCK) if callable(reader) else response.read(64 * 1024)
                        if not chunk:
                            break
                        if received + len(chunk) > expected_body or offset + received + len(chunk) > entry.size_bytes:
                            raise IntegrityError('Server sent too many bytes; stopped without writing the excess.')
                        destination.write(chunk)
                        received += len(chunk)
                        transferred += len(chunk)
                        if router is not None:
                            router.success(entry, base)
                        progress.advance(len(chunk))
                    destination.flush()
                    os.fsync(destination.fileno())
                if received != expected_body or offset + received != entry.size_bytes:
                    raise DownloadError(f'Connection ended before the complete file ({offset + received}/{entry.size_bytes} bytes); resuming on retry.')
            hashes = verify_file(entry, part)
            publish_no_overwrite(part, final)
            return hashes
        except IntegrityError:
            raise
        except (urllib.error.URLError, OSError, TimeoutError, http.client.HTTPException, DownloadError) as exc:
            if isinstance(exc, OSError) and exc.errno in (errno.ENOSPC, errno.EACCES, errno.EROFS):
                raise DownloadError('本地磁盘空间或写入权限错误；临时文件保留，请检查目标磁盘。') from exc
            classification = error_classification(exc)
            if attempt + 1 == attempts:
                raise NetworkError(f'{attempts} 次官方线路连接/传输失败（最后类型: {classification}）；临时文件已保留。运行 --diagnose 生成可分享的网络报告。', transferred) from exc
            delay = retry_delay(exc, attempt + 1)
            if not isinstance(exc, urllib.error.HTTPError) or exc.code not in (429, 503):
                delay = min(2.0, delay)
            print(f'    {classification}; {delay:.0f}s 后切换/重试官方线路。临时文件保留。', flush=True)
            time.sleep(delay)
    raise AssertionError('unreachable')


def atomic_json(path: Path, value: dict) -> None:
    assert_no_symlink(path)
    temporary = path.with_name(path.name + '.tmp')
    assert_no_symlink(temporary)
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, 'O_NOFOLLOW', 0)
    with os.fdopen(os.open(temporary, flags, 0o600), 'w', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def log_event(path: Path, value: dict) -> None:
    assert_no_symlink(path)
    flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND | getattr(os, 'O_NOFOLLOW', 0)
    with os.fdopen(os.open(path, flags, 0o600), 'a', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, allow_nan=False) + '\n')


def plan_disk_usage(entries: list[Entry], root: Path) -> tuple[int, int, int, int]:
    present_count = present_bytes = partial_bytes = 0
    for entry in entries:
        final = entry.path(root)
        size = checked_file_size(final)
        if size is not None:
            if size != entry.size_bytes:
                raise IntegrityError(f'Existing final file has the wrong size; preserved: {final}')
            present_count += 1
            present_bytes += size
        else:
            partial = checked_file_size(final.with_name(final.name + '.part')) or 0
            if partial > entry.size_bytes:
                raise IntegrityError(f'Oversized partial file; preserved: {final}.part')
            partial_bytes += partial
    return present_count, present_bytes, partial_bytes, sum(e.size_bytes for e in entries) - present_bytes - partial_bytes


def print_plan(entries: list[Entry], root: Path, available: int, reserve: int, present: int, remaining: int) -> None:
    print(f'SimNICT 胸部完整数据：第 {PART_NUMBER}/3 份 ({VERSION})', flush=True)
    print(f'Destination / 保存位置: {root}')
    print(f'Pinned plan: {EXPECTED_COUNT:,} volume files, {human_size(EXPECTED_BYTES)} (compressed .nii.gz)')
    print(f'This run: {len(entries):,} volumes. Existing size-matched files: {present:,}; checksums will be verified.')
    print(f'Remaining payload: {human_size(remaining)}; free: {human_size(available)}; reserve: {human_size(reserve)}')
    for identifier, count in sorted(collections.Counter(e.identifier for e in entries).items()):
        print(f'  {identifier}: {count} | source license label: {SOURCE_LICENSE_LABELS[identifier]}')
    print('Only published chest ICT NIfTI files; no abdomen, simulated LDCT, projections or labels.')
    print('All three shards together contain 5,512 volumes: 5,477 pre-training and 35 downstream cases in the authors\' table. This shard does not identify individual downstream cases.')
    print('Volumes are not a unique-patient count. Published ICT files are preprocessed reference images; this plan does not certify every clinical acquisition was standard-dose or every volume is artifact-free.')
    print('Terms / 使用条款: SimNICT card-wide label CC BY-ND 4.0; review each original source and preserve attribution/applicable restrictions.')
    print('  https://huggingface.co/datasets/YutingHe-list/SimNICT')
    print('  https://arxiv.org/abs/2410.01591')
    print('No Hugging Face token/login is used. Download access is public Internet Archive HTTPS only.', flush=True)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--data-dir', type=Path, default=None, help='Parent download directory; default is the terminal current working directory. A unique numbered data subdirectory is created inside it.')
    parser.add_argument('--check', '--dry-run', dest='check', action='store_true', help='Validate pinned plan and display free-space estimate; no payload download and no files created.')
    parser.add_argument('--probe', action='store_true', help='HEAD-only access check on the first selected file; no payload downloaded and no files created.')
    parser.add_argument('--diagnose', action='store_true', help='Probe all selected source routes with at most 64 KiB each; write redacted network_diagnostic.json/.txt; no CT saved and no capacity requirement.')
    parser.add_argument('--direct', action='store_true', help='Explicitly ignore system/environment proxies and connect directly. Default preserves existing HTTP_PROXY/HTTPS_PROXY.')
    parser.add_argument('--yes', action='store_true', help='Accept the displayed plan/terms acknowledgement without the interactive confirmation.')
    parser.add_argument('--limit', type=int, help='Select only the first N entries in fixed selection-rank order (testing).')
    parser.add_argument('--max-files', type=int, help='Download at most N new volumes this run; verified existing files do not count.')
    parser.add_argument('--verify-only', action='store_true', help='Rehash existing selected files and build logs; do not download missing files.')
    parser.add_argument('--retries', type=int, default=5, help='Extra network attempts per file (default 5); every official route is tried at least once.')
    parser.add_argument('--timeout', type=int, default=30, help='Per socket operation timeout in seconds (default 30); OS DNS lookup may take longer.')
    parser.add_argument('--version', action='version', version=VERSION)
    args = parser.parse_args(argv)
    for name in ('limit', 'max_files', 'timeout'):
        if getattr(args, name) is not None and getattr(args, name) <= 0:
            parser.error(f'--{name.replace("_", "-")} must be positive')
    if args.retries < 0 or args.retries > 20:
        parser.error('--retries must be 0..20')
    try:
        entries = load_manifest(Path(__file__).resolve().with_name(MANIFEST_NAME))
        router = MirrorRouter(load_mirrors(Path(__file__).resolve().with_name(MIRRORS_NAME)))
        if args.limit:
            entries = entries[:args.limit]
        data_dir = Path(os.path.abspath(args.data_dir if args.data_dir is not None else Path.cwd()))
        assert_no_symlink(data_dir)
        root = data_dir / DATA_SUBDIR
        assert_no_symlink(root)
        if args.diagnose:
            return run_diagnosis(entries, router, make_opener(args.direct), root, direct=args.direct)
        router.apply_diagnostic_report(root / 'network_diagnostic.json')
        present, existing_bytes, partial_bytes, remaining = plan_disk_usage(entries, root)
        reserve = max(20 * 2**30, sum(e.size_bytes for e in entries) // 10)
        ancestor = data_dir
        while not ancestor.exists():
            ancestor = ancestor.parent
        available = shutil.disk_usage(ancestor).free
        print_plan(entries, root, available, reserve, present, remaining)
        if not args.verify_only and not args.probe:
            check_capacity(data_dir, remaining, reserve)
        if args.probe:
            probe_url = router.candidates(entries[0])[0][1]
            print(f'HEAD probe: {urllib.parse.urlsplit(probe_url).hostname}', flush=True)
            with request(make_opener(args.direct), probe_url, method='HEAD', timeout=args.timeout) as response:
                print(f'HEAD probe: HTTP {response.status}; Content-Length={response.headers.get("Content-Length", "unknown")}; Accept-Ranges={response.headers.get("Accept-Ranges", "unknown")}')
                if response.headers.get('Content-Length') and int(response.headers['Content-Length']) != entries[0].size_bytes:
                    raise IntegrityError('HEAD Content-Length differs from pinned file size.')
            return 0
        if args.check:
            print('Check complete. No image payload downloaded; no files created.')
            return 0
        if not args.yes:
            if not sys.stdin.isatty():
                raise DownloadError('Interactive confirmation is required; run in a terminal or add --yes after reviewing the plan.')
            answer = input('确认以上位置、容量及适用使用条款后开始 / Continue? [y/N]: ').strip().lower()
            if answer not in ('y', 'yes'):
                print('Cancelled; no payload downloaded.')
                return 0
        make_directory(root)
        lock_path = root / '.down_SimNICT_chest.lock'
        assert_no_symlink(lock_path)
        lock_descriptor = os.open(lock_path, os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        try:
            try:
                fcntl.flock(lock_descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise DownloadError('Another chest downloader is using this destination. Wait for it to finish.') from exc
            # Repeat under lock; another process may have changed progress since preview.
            plan_disk_usage(entries, root)
            opener = None if args.verify_only else make_opener(args.direct)
            run_started = utc_now()
            completed = downloaded = missing = failures = consecutive_network_failures = 0
            network_aborted = False
            state = {'version': VERSION, 'part_number': PART_NUMBER, 'manifest_sha256': MANIFEST_SHA256, 'mirrors_sha256': MIRRORS_SHA256, 'started_utc': run_started,
                     'destination': str(root), 'planned_volumes': len(entries), 'files': {}}
            state_path, log_path = root / 'download_status.json', root / 'download_log.jsonl'
            for index, entry in enumerate(entries, 1):
                final = entry.path(root)
                is_existing = checked_file_size(final) is not None
                if not is_existing and args.verify_only:
                    missing += 1
                    continue
                if not is_existing and args.max_files is not None and downloaded >= args.max_files:
                    continue
                print(f'[{index}/{len(entries)}] {"Verify" if is_existing else "Download"}: {entry.identifier}/{entry.filename} ({entry.size_bytes / 1e6:,.1f} MB)', flush=True)
                try:
                    hashes = verify_file(entry, final) if is_existing else download_one(entry, final, opener, retries=args.retries, timeout=args.timeout, reserve_bytes=reserve, router=router)
                    completed += 1
                    if not is_existing:
                        downloaded += 1
                        consecutive_network_failures = 0
                    event = {'time_utc': utc_now(), 'status': 'verified_existing' if is_existing else 'downloaded_verified',
                             'identifier': entry.identifier, 'filename': entry.filename, 'source_dataset': entry.source_dataset,
                             'download_order': entry.rank, 'size_bytes': entry.size_bytes, 'path': str(final),
                             'source_url': entry.url, **hashes, **inspect_nifti_header(final)}
                    print(f'    OK | verified this run: {completed}/{len(entries)} | new downloads: {downloaded}', flush=True)
                except (DownloadError, OSError, ValueError) as exc:
                    failures += 1
                    if isinstance(exc, NetworkError):
                        consecutive_network_failures = 0 if exc.transferred_bytes else consecutive_network_failures + 1
                        network_aborted = consecutive_network_failures >= 3
                    event = {'time_utc': utc_now(), 'status': 'error', 'identifier': entry.identifier,
                             'filename': entry.filename, 'error': str(exc)}
                    print(f'    ERROR: {exc}', file=sys.stderr, flush=True)
                state['files'][f'{entry.identifier}/{entry.filename}'] = event
                state.update(updated_utc=utc_now(), verified_this_run=completed, downloaded_this_run=downloaded, failures_this_run=failures)
                log_event(log_path, event)
                atomic_json(state_path, state)
                if network_aborted:
                    print('连续三个待下载文件的所有官方线路均没有收到任何数据，已停止本次运行，避免继续逐一空等。', file=sys.stderr, flush=True)
                    print('请先运行同一脚本加 --diagnose；已有文件及 .part 均保留。\n' + network_help(), file=sys.stderr, flush=True)
                    break
            print(f'Finished: verified {completed}/{len(entries)} selected volumes; downloaded {downloaded} new; errors {failures}; missing in verify-only {missing}.')
            print(f'Log: {log_path}\nStatus / NIfTI metadata: {state_path}')
            print('Re-run the same command to continue. Completed files are checksum-verified before being skipped.')
            return 2 if network_aborted else 1 if failures or (args.verify_only and missing) else 0
        finally:
            os.close(lock_descriptor)
    except KeyboardInterrupt:
        print('\nStopped safely. Re-run the same command to resume .part files.', file=sys.stderr)
        return 130
    except (DownloadError, OSError, ValueError, KeyError) as exc:
        safe_message = error_classification(exc) if isinstance(exc, (urllib.error.URLError, ssl.SSLError, socket.gaierror, TimeoutError)) else str(exc)
        print(f'ERROR: {safe_message}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
